package com.aeriaplugins.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scoreboard.Team;
import java.util.List;

// ========================================================================
// CLASSE: AeriaBoard
// OBJETIVO: Criar e atualizar o painel lateral do jogador de forma suave (sem "piscar").
// ========================================================================
public class AeriaBoard {
    private final Scoreboard scoreboard;
    private Objective objective;
    private final Player player;
    
    // Variável que ajuda a saber se estamos num servidor antigo (como o 1.8) ou moderno
    private static boolean isLegacyServer = true;

    static {
        try {
            Team.class.getMethod("setColor", ChatColor.class);
            isLegacyServer = false;
        } catch (Throwable e) {
            isLegacyServer = true;
        }
    }

    // ------------------------------------------------------------------------
    // MÉTODO: Construtor (AeriaBoard)
    // Chamado na primeira vez que o jogador entra no servidor. Ele regista o quadro em branco.
    // ------------------------------------------------------------------------
    public AeriaBoard(Player player) {
        this.player = player;
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        this.scoreboard = manager != null ? manager.getNewScoreboard() : null;
        
        if (this.scoreboard != null) {
            Objective old = this.scoreboard.getObjective("aeria");
            if (old != null) old.unregister();

            // Regista o título superior do quadro (Sidebar)
            try {
                this.objective = (Objective) Scoreboard.class.getMethod("registerNewObjective", String.class, String.class, String.class)
                        .invoke(this.scoreboard, "aeria", "dummy", "aeria");
            } catch (Throwable t) {
                this.objective = this.scoreboard.registerNewObjective("aeria", "dummy");
            }
            
            if (this.objective != null) {
                this.objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            }
            player.setScoreboard(this.scoreboard); // Envia o quadro vazio para o ecrã do jogador
        } else {
            this.objective = null;
        }
    }

    // Atualiza apenas o Título do topo
    public void updateTitle(String title) {
        if (objective != null) {
            objective.setDisplayName(title);
        }
    }

    // ------------------------------------------------------------------------
    // MÉTODO: updateLines
    // Atualiza as linhas do quadro usando "Equipas" (Teams).
    // Isto é um truque para atualizar o texto sem fazer o painel piscar de segundo a segundo.
    // ------------------------------------------------------------------------
    public void updateLines(List<String> lines) {
        if (scoreboard == null || objective == null) return;
        int size = Math.min(lines.size(), 15); // O limite visual do Minecraft são 15 linhas
        
        for (int i = 0; i < 15; i++) {
            // Cria um identificador único para cada linha usando as cores do jogo
            String entry = ChatColor.values()[i].toString() + ChatColor.RESET;
            Team team = scoreboard.getTeam("line_" + i);
            
            if (i < size) {
                if (team == null) {
                    team = scoreboard.registerNewTeam("line_" + i); // Regista uma nova "equipa"
                }
                if (!team.hasEntry(entry)) {
                    team.addEntry(entry);
                }

                String line = lines.get(size - 1 - i); // Lê de baixo para cima
                
                // Divisão do texto para versões antigas (1.8 suporta no máximo 16 letras na prefix/suffix)
                if (isLegacyServer) {
                    if (line.length() > 16) {
                        String prefix = line.substring(0, 16);
                        String lastColors = ChatColor.getLastColors(prefix);
                        String suffix = lastColors + line.substring(16);
                        
                        team.setPrefix(prefix);
                        team.setSuffix(suffix.length() > 16 ? suffix.substring(0, 16) : suffix);
                    } else {
                        team.setPrefix(line);
                        team.setSuffix("");
                    }
                } else {
                    // Nas versões modernas, a prefix pode ser gigante e não tem de dividir o texto
                    try {
                        team.setPrefix(line);
                        team.setSuffix("");
                    } catch (Throwable ignored) {}
                }
                
                objective.getScore(entry).setScore(i + 1);
                
                // Formatação moderna (Paper 1.20.4+): Apaga os números vermelhos à direita do quadro
                try {
                    java.lang.reflect.Method method = objective.getScore(entry).getClass().getMethod("numberFormat", 
                            Class.forName("io.papermc.paper.scoreboard.numbers.NumberFormat"));
                    Object blankFormat = Class.forName("io.papermc.paper.scoreboard.numbers.NumberFormat").getMethod("blank").invoke(null);
                    method.invoke(objective.getScore(entry), blankFormat);
                } catch (Exception ignored) {}
            } else {
                // Se sobrarem linhas antigas sem uso, limpa-as
                if (team != null) {
                    team.unregister();
                }
                scoreboard.resetScores(entry);
            }
        }
    }

    // ------------------------------------------------------------------------
    // MÉTODO: delete
    // Apaga o quadro totalmente, utilizado quando o jogador sai do servidor.
    // ------------------------------------------------------------------------
    public void delete() {
        if (player != null && player.isOnline()) {
            ScoreboardManager m = Bukkit.getScoreboardManager();
            if (m != null) player.setScoreboard(m.getMainScoreboard());
        }
        if (scoreboard != null) {
            for (Team team : scoreboard.getTeams()) {
                try { team.unregister(); } catch (Throwable ignored) {}
            }
        }
    }
}